/*
 * @Description: pm2 
 * @Version: 0.0.1
 * @Author: Chen
 * @Date: 2021-01-17 21:41:36
 * @LastEditors: Chen
 * @LastEditTime: 2021-01-17 23:52:33
 */
require('babel-register');
require('babel-polyfill');
require('./bin/www')